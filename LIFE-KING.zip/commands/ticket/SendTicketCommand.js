// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('', '', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تـذكـرة - تـفـعـيل`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("قـسـم الـتـفـعـيـل")
      .setDescription(` <a:1108524691062259713:1267215443177902120> - تـذكـرة الـتـفـعـيـل

**__ <a:00:1289891322936688741>  — مـرحـبـا بـك عـزيـزي الـعـضـو فـي قـسـم الـتـفـعـيـل .

 — <:LK:1289524430220820593>   لـلـتـفـعـيـل فـي  لايـف كـيـنـق الـرجـاء الـنـقـر عـلـى ( تـذكـرة تـفـعـيـل ) .

<a:Eror3:1267214247855919227>  — ويـرجـى الالـتـزام بالانـظـمـة الـمـوضـحـة ادنـاه .

1 — احـتـرام الاداري .
2 — عـدم اكـثـار مـنـشـن
3 — عـدم الـتـأخـر فـي الـرد

<a:AnimEmoteLoveRed:1267207798358282310> — نـرجـو الالـتـزام بالانـظـمـة وعـدم مـخـالـفـتـهـا .

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق ) __**`) 
    message.channel.send({embeds: [embed] , components: [button]})
  }
}