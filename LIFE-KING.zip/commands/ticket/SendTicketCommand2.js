// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('', '', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open2')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تذكرة - اونر`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("قسم الاونرات")
      .setDescription(`** **__ طلب اونر .

<a:00:1267215437603537058> ملاحظات مهمة

1 - يمنع فتح التذكرة لأسباب تافهه ولا تستحق تدخل  <@&1286329738733813885> 

2 - يمنع اكثار المنشن

3 - في حال لديك شكوى لم تحل يجب ارفاق الأدلة

الكافية.

4 - في حال مخالفتك لأحد الانظمة ( تايم 16 )

<a:0white:1267208268691017861> - قيادة  حياة الملوك تحت خدمتكم دائما
وابدا .

( مع تمنياتنا لكم بالتوفيق ) __**)

//.setImage("https://media.discordapp.net/attachments/1270258103538946090/1289866880034672715/phonto.jpg?ex=66fbb324&is=66fa61a4&hm=eaefd436f7e419c53b7d3526c9e8a058319f910013c626186609157605794dac&")

    message.channel.send({
      embeds: [embed],
      components: [button]
    })
  }
}