// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('', '', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تـذكـرة - اونر`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("طلب اونر")
      .setDescription(` <:pp449:1290270813811118113> - طلب اونر

**__ طلب اونر.

<a:00:1267215437603537058> ملاحظات مهمة

1 - يمنع فتح التذكرة لأسباب تافهه ولا تستحق تدخل  <@&1286329738733813885> 

2 - يمنع اكثار المنشن

3 - في حال لديك شكوى لم تحل يجب ارفاق الأدلة
الكافية.

4 - في حال مخالفتك لأحد الانظمة ( تايم 16 )

<a:0white:1267208268691017861> - قيادة  حياة الملوك تحت خدمتكم دائما
وابدا .

( مع تمنياتنا لكم بالتوفيق ) __**`) 
    message.channel.send({embeds: [embed] , components: [button]})
  }
}