// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('', '', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open4')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تذكرة - شكوى`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("قسم الشكاوي")
      .setDescription(`** <:pp449:1069609005804175472> - رفع شكوى

<:pp407:1069609064545402880> - مرحبآ بك عزيزي العضو في سيرفر لايف كينق لرفع شكوى قم بفتح تكت     
      
<:pp186:1069609208326127686> - ملاحظة
      
1 - يرجى عدم فتح تذكره على اسباب تافهه 
      
2 - يرجى تعبئه الاستبيان كامل 
      
3 - بعد تعبئه الاستبيان انتضر الرد من قبل الادارة بدون ازعاج  
      
<:pp521:1069608739885285407> - ادارة سيرفر  لايف كينق تحت خدمتكم **`)
.setImage("https://cdn.discordapp.com/attachments/1270258103538946090/1286671923232636938/C12C0F8C-8E3C-4E24-AECD-839568E6F9D1.jpg?ex=66f4081b&is=66f2b69b&hm=40b4332e90c72d985f623c4ee8cc0e54779430f4b102597aead9eb4e0fa509fc&")

    message.channel.send({
      embeds: [embed],
      components: [button]
    })
  }
}