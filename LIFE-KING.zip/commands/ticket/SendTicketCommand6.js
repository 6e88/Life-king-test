// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('', '', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender) && message.author.id != "1286329738733813885") return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open6')
          .setStyle(Discord.ButtonStyle.Primary)
          .setLabel(`تذكرة - تقديم`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor('EAE843')
      .setTitle("قسم التقديم")
      .setDescription(`** <:pp449:1069609005804175472> - تكت تقديم إدارة

<:pp407:1069609064545402880> - مرحبآ بك عزيزي العضو في سيرفر وندر ستي للتقديم على إدارة لايف كينق قم بفتح تكت
      
<:pp186:1069609208326127686> - ملاحظة
      
1 - يرجى تعبئه الاستبيان كامل 
      
2 - اذا تم قبولك يرجى التوجه لـ روم القسم 
      
3 - اذا تم قبولك يرجى الالتزام ب القوانين كامله

<:pp521:1069608739885285407> - متمنين لكم اوقات ممتعه في 𝗟𝗶𝗙𝗲 𝗞𝗶𝗻𝗚**`)
//.setImage("")

    message.channel.send({
      embeds: [embed],
      components: [button]
    })
  }
}