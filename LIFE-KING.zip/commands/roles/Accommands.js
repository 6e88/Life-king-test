const { ActionRowBuilder, StringSelectMenuBuilder } = require('@discordjs/builders');
const { Client, Message, SelectMenuOptionBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
let rolesDb = [
  ["1286329890353840128","1286329921412661442","1286329922507247631","1286329891515666483"],
  ["1286329884154794024","1286329921412661442","1286329922507247631","1286329891515666483"],
  ["1286329954560249978","1286329965637533696"],
  ["1286329953096568848","1286329965637533696"],
  ["1286329951569580105","1286329965637533696"],
  ["1286329972843090072","1286329974193918003"],
  ["1286329936201781408","1286329940052017252"],
  ["1286329937397153856","1286329940052017252"],
  ["1286329889007472701","1286329921412661442","1286329922507247631","1286329891515666483"]
]
module.exports = class AcceptCommand extends BaseCommand {
  constructor() {
    super('قبول', 'roles', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if(!message.member?.roles.cache.has("1287323086055669790") && message.member.id != "1287323086055669790") return message.reply({content:"لاتملك صلاحية استخدام هذا الامر"})
    let ob = [
      {
        name : "الـحرس الـملـكـي",
        id :"0"
      },
      {
        name : "الــشــرطــة",
        id :"1"
      },
      {
        name : "رئـاسـه امـن دولـة",
        id :"8"
      }
    ]
    let ob2 = [{
      name : "تـريـكـسـتر",
      id : "2"
    },{
      name : "سـوبـيـا",
      id : "3"
    },{
      name : "مـافـيا",
      id : "4"
    }]
    let ob3 = [{
      name : "اعـلامـي",
      id: "5"
    },{
      name :"مـحـامـي",
      id : "6"
    },{
      name : "قـاضـي",
      id : "7"
    }]
    if(!message.mentions.members?.first()) return message.reply({content : "الرجاء منشن عضو"})
    let s = new StringSelectMenuBuilder()
    .setCustomId("kia3at")
    .setMaxValues(1)
    .setPlaceholder("القطاعات الحكومية")
    ob.forEach(x=>{
      s.addOptions([new SelectMenuOptionBuilder().setLabel(x.name).setValue(x.id)])
    })
    let s2 = new StringSelectMenuBuilder()
    .setCustomId("esabat")
    .setMaxValues(1)
    .setPlaceholder("العصابات")
    ob2.forEach(x=>{
      s2.addOptions([new SelectMenuOptionBuilder().setLabel(x.name).setValue(x.id)])
    })
    let s3 =   new StringSelectMenuBuilder()
    .setCustomId("other")
    .setMaxValues(1)
    .setPlaceholder("وظائف اخرى")
    ob3.forEach(x=>{
      s3.addOptions([new SelectMenuOptionBuilder().setLabel(x.name).setValue(x.id)])
    })
    let rowq = new ActionRowBuilder()
    .addComponents(
      s
    )
    let rowq2 = new ActionRowBuilder()
    .addComponents(
      s2
    )
    let rowq3 = new ActionRowBuilder()
    .addComponents(
      s3
    )
   let dk = await  message.reply({components :[rowq,rowq2,rowq3]})
    const filter = (interaction) => interaction.user.id == message.author.id;

    let collected = await dk.awaitMessageComponent({ filter, time: 15_000}).catch((c) =>{
        console.log(`After five seconds, ${c.size} messages are collected.`)
        message.channel.send(":x: | تم الغاء الامر لعدم التفاعل")
    });
      if(!collected) return
    rolesDb[Number(collected.values[0])].forEach(k=>{
      message.mentions.members.first()?.roles.add(k).catch(null)
    })
    collected.reply({content : `
تم قبول | ${message.mentions.members.first()}

في وظيفة | ${collected.component.options.find(x=> x.value == collected.values[0]).label}

المسؤول عن القبول | ${message.member}`})
    let ob77 = ob.concat(ob2,ob3)
    
    client.channels.cache.get("1084245536850313357").send({
      content : `
تم قبول العضو : ${message.mentions.members.first()}
بواسطة الادمن : ${message.member}
كـ : ${ob77.find(k=>k.id == collected.values[0])?.name}
`
    })
    }
}