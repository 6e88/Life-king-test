// @ts-nocheck
const { Client, Message, EmbedBuilder } = require('discord.js');
const bank = require('../../models/bank');
const BaseCommand = require('../../utils/structures/BaseCommand');

module.exports = class TransCommand extends BaseCommand {
  constructor() {
    super('ايداع', 'eco', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
   
      if(message.channel.id != "1286331065396363265") return message.reply({content : "الرجاء الذهاب الى روم : <#1286331065396363265>"})
    if(!args[0]) return message.reply({content :"قم بادخال مبلغ"})

    if(isNaN(args[0]) || parseInt(args[0])<=0 ) return message.reply({content :"رجاء قم بتحديد رقم صالح"}) 
    let sender= await bank.findOne({user:message.member?.id})
    if(sender?.amount < parseInt(args[0])) return message.reply({content : `رصيدك غير كافي لهذه العملية`})

    sender.bank += parseInt(args[0])
    sender.amount -= parseInt(args[0])
    await sender.save()
    let embe = new EmbedBuilder()
    .setColor("Gold")
    .setTitle("ايداع مبلغ")
    .setTimestamp()
    .setThumbnail(client.user.avatarURL())
    .setDescription(`**مصرف الراجحي | <:emoji_215:1073167524750962809>**

    **ايداع مبلغ | <:pp889:1069608352096735343>
        
        العميل : ${message.member} | <:pp407:1069609064545402880>

        المبلغ الذي تم ايداعه : ${args[0]} | <:emoji_241:1073173522177871932> **`)
await message.channel.send({embeds: [embe]})

  }
}