// @ts-nocheck
const { Client, Message } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const config = require("../../config");
const proDb = require('pro.db');
module.exports = class GameCommand extends BaseCommand {
  constructor() {
    super('قيم', 'fly', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if(!message.member?.roles.cache.has(config.fgRoleID) &&  message.author.id != "1287323086055669790") return message.reply({content:`:x: | لا تمتلك صلاحية لبدأ قيم`})
      if(message.channel.id != "1286330850765439059" && message.author.id != "1287323086055669790") return message.reply({content : `لاستخدام الامر الرجاء الذهاب الى : <#1286330850765439059>`})
    let filter = (m) => m.author.id == message.author.id
    let q1 = await message.reply({content :"ايدي كابتن الرحلة : "})
    let a1 = await message.channel.awaitMessages({filter:filter,max:1})
    if(!a1.first()) return
    let capId = a1.first()
    capId.delete()
    await q1.delete()
    let q2 = await message.reply({content :"ايدي مساعد كابتن الرحلة : "})
    let a2 = await message.channel.awaitMessages({filter:filter,max:1})
    if(!a2.first()) return
    let cocapId = a2.first()
    cocapId.delete()
    await q2.delete()
    let q3 = await message.reply({content :"وقت الرحلة: "})
    let a3 = await message.channel.awaitMessages({filter:filter,max:1})
    if(!a3.first()) return
    let time = a3.first()
    time.delete()
    await q3.delete()
    let q4 = await message.reply({content :"وقت الارسال: "})
    let a4 = await message.channel.awaitMessages({filter:filter,max:1})
    if(!a4.first()) return
    let stime = a4.first()
    stime.delete()
    await q4.delete()
     let q5 = await message.reply({content :"وقت الاقلاع: "})
    let a5 = await message.channel.awaitMessages({filter:filter,max:1})
    if(!a5.first()) return
    let atime = a5.first()
    atime.delete()
    await q5.delete()
    proDb.add("nnny",1)
    message.channel.send({
      content:`**__ إعـلان رحـلـة / 𝗟𝗶𝗙𝗲 𝗞𝗶𝗻𝗚 

 قائد الـرحـلـة | ${capId.content}

 ايـدي قائد الرحلة  | ${capId.content}

 ايدي مـسـاعـد الـرحـلـة | ${cocapId.content}

رقم الـرحـلـة | ${proDb.get("nnny")}

وقـت الـرحـلة | ${time.content}

وقـت الارسال | ${stime.content}

وقـت الاقــلاع | ${atime.content}

[اذا التصويت اقل من ال 15 ينلغي القيم ]

[ في حال ماعرفت كيف تدخل القيم توجه الى <#1286330811150372969> ]
__**
@everyone
`
    })
    message.channel.send({content: "https://media.discordapp.net/attachments/1270258103538946090/1289866882119368704/phonto.jpg?ex=66fd04a5&is=66fbb325&hm=a32d2dad13e735a4db8ff7427bdbb621c2c2ad12d2f4552347af08d0e83e7f49&=&format=webp&width=1408&height=399"})
  }
}