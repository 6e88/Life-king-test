//@ts-nocheck
// https://discord.js.org/#/docs/main/stable/class/Client?scrollTo=e-interactionCreate
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('@discordjs/builders');
const { Client, PermissionFlagsBits, ButtonStyle } = require('discord.js');
const BaseEvent = require('../utils/structures/BaseEvent');
const s = require('../config');
const db = require("pro.db")

const { catgs1 } = require('../config');
module.exports = class InteractionCreateEvent extends BaseEvent {
  constructor() {
    super('');
  }
  /**
   * 
   * @param {Client} client 
   * @param {import('discord.js').Interaction} interaction 
   */
  async run(client, interaction) {
    if (!interaction.isButton()) return
    let sri = "1286329738733813885" //ايدي رتبة السبورت
    if (interaction.customId == "open1") {
        db.add("www2",1)
      let ch = await interaction.guild?.channels.create({
        name: `ticket-${db.get("www2")}`,
        permissionOverwrites: [
          {
            id: interaction.guildId,
            deny: PermissionFlagsBits.ViewChannel
          },
          {
            id: interaction.member.id,
            allow: [PermissionFlagsBits.ViewChannel,PermissionFlagsBits.MentionEveryone,PermissionFlagsBits.AttachFiles]
          },
          {
            id: sri,
            allow: PermissionFlagsBits.ViewChannel
          }
        ],
        parent: catgs1
      })
      ch.send({
        content: `
${interaction.member} - <@&${sri}>

**__ مرحبا بك عزيزي العضو في قسم الاونرز .__**

<:LK:1289524430220820593> - **__ نرجوا منك عزيزي العضو __**

**__ <:1201960142636339270:1286395206677041233> إنتظار إستلام تذكرتك من أحد طاقم الإدارة __**,
        embeds: [new EmbedBuilder()
          .setTitle(`الاعلان`)
          .setTimestamp()
          .setColor(0xEAE843)
          .setDescription(`**__ <:pp449:1069609005804175472> -  مرحبا بك عزيزي العضو في قسم طلب اعلان 

<:pp521:1069608739885285407> - نرجو منك عزيزي العضو إنتضار إستلام التكت من قبل الادارة __**`)],
        components: [new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId("claim1")
              .setStyle(ButtonStyle.Success)
              .setLabel("استلام"),
            new ButtonBuilder()
              .setCustomId("trk1")
              .setStyle(ButtonStyle.Secondary)
              .setLabel("ترك"),
            new ButtonBuilder()
              .setCustomId("delete1")
              .setStyle(ButtonStyle.Danger)
              .setLabel("حذف")
          )]
      })
      interaction.reply({ content: `${ch}`, ephemeral: true })
    }
  }
}