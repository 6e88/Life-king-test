const BaseEvent = require('../../utils/structures/BaseEvent');

module.exports = class MessageEvent extends BaseEvent {
  constructor() {
    super('messageCreate');
  }

  async run(client, message) {
    if (message.content === "-ارسال") {
      if (!message.member.roles.cache.has("1053317581043404871") && message.author.id !== client.user.id) return;
      message.delete();
      message.channel.send({content: "https://media.discordapp.net/attachments/1270258103538946090/1286671924373749821/D53F5702-7677-4D1B-9787-BEA06A18760B.jpg?ex=66f4081b&is=66f2b69b&hm=f6a35dce0948a0531f1b227c2dbaa080dce2473921097d61f872a39fa732455c&=&format=webp"})
      message.channel.send({
        content: `**
\` # \` تم وصول طائرة لايف كينق الجوية ✈️ ,

\` # \` الرجاء من حجز تذكرة الركوب للطائرة تم فتح أبواب الطائرة من قبل ,

\` # \` نرجو من الجميع الانتباه وعدم ازعاج الهوست وقراءة: <#1286330847460458557>

\` # \` لتجنب المشاكل والتحذيرات وشكراً لكم

-
~~ @everyone ~~
**
 `});
      message.channel.send({content: "https://cdn.discordapp.com/attachments/1286330575954771998/1286383586592952413/1076927196993699870.jpg?ex=66f3a452&is=66f252d2&hm=7597db589549cd7f91121d9f31fe1d1156975ac3914814d3ed309e3acea36ecb&"})
      return;
    }

    if (message.content === "-تصويت") {
      if (!message.member.roles.cache.has("1287323086055669790") && message.author.id !== client.user.id) return;
      message.delete();
      message.channel.send({content: "https://media.discordapp.net/attachments/1270258103538946090/1286671924373749821/D53F5702-7677-4D1B-9787-BEA06A18760B.jpg?ex=66f4081b&is=66f2b69b&hm=f6a35dce0948a0531f1b227c2dbaa080dce2473921097d61f872a39fa732455c&=&format=webp"})
      message.channel.send({
        content: `**
\` # \` تـم فـتـح شـراء تـذكـرة لـدولـة 
\` # \` \` 𝗟𝗶𝗙𝗲 𝗞𝗶𝗻𝗚 | لايف كينق \` \` # \`

\` # \` <#1286330850765439059> 
\` # \` <#1286330850765439059> 
\` # \` <#1286330850765439059> 

\` # \`مـن أراد ركـوب الـطـائـرة الـرجـاء شراء تـذكـرة والأسـتعداد للـرحلـة ومـراجـعـة جـميع القـوانـين 
-
~~ @everyone ~~
**`
      });
      message.channel.send({content: "https://cdn.discordapp.com/attachments/1286330575954771998/1286383586592952413/1076927196993699870.jpg?ex=66f3a452&is=66f252d2&hm=7597db589549cd7f91121d9f31fe1d1156975ac3914814d3ed309e3acea36ecb&"})
      return;
    }

if (message.content === "-تم") {
  if (!message.member.roles.cache.has("1053317581043404871") && message.author.id !== client.user.id) return;
  message.delete();
  message.channel.send({content: "https://media.discordapp.net/attachments/1064519307679244299/1100857369287733338/29_.png"})
  message.channel.send({
    content: `**
\` # \`تم فحص جميع الركاب بنجاح ✅

\` # \` يرجى الأن كتابة لبدء القيم :   \`  \`
-
\` الاداري: \`  ${message.author}
**
`
  });
  message.channel.send({content: "https://media.discordapp.net/attachments/1064519307679244299/1100857369287733338/29_.png"})
  return;
}


    if (message.content === "-بدء") {
      if (!message.member.roles.cache.has("1053317581043404871") && message.author.id !== client.user.id) return;
      message.delete();
      message.channel.send({content: "https://media.discordapp.net/attachments/1064519307679244299/1100857369287733338/29_.png"})
      message.channel.send({
        content: `**
\` # \` تم فحص جميع ركاب الطائرة للمطار الدولي وتم حجز جميع التذاكر ✅ نرجو من الجميع الانتباه وربط الاحزمة وقراءة :

\` # \` <#1041042263263948961>
    
\` # \` لتجنب المشاكل والتحذيرات وشكراً لكم
-
~~ <@&1039273369696223273> ~~
**`
      });
      message.channel.send({content: "https://media.discordapp.net/attachments/1064519307679244299/1100857369287733338/29_.png"})
      return;
    }

    if (message.content === "-تجوين") {
      if (!message.member.roles.cache.has("1053317581043404871") && message.author.id !== client.user.id) return;
      message.delete();
      message.channel.send({content: "https://media.discordapp.net/attachments/1064519307679244299/1100857369287733338/29_.png"})
      message.channel.send({
        content: `**
\` # \` يرجى من جميع المواطنين المشترين تذاكر التجوين علي ${message.author} , نرجو من الجميع الانتباه وربط الاحزمة وقراءة :

\` # \` <#1041042263263948961>
    
\` # \` لتجنب المشاكل والتحذيرات وشكراً لكم
-
~~ <@&1039273369696223273> ~~
**`
      });
      message.channel.send({content: "https://media.discordapp.net/attachments/1064519307679244299/1100857369287733338/29_.png"})
      return;
    }

    if (message.content === "ق" || message.content === "قفل") {
      if (!message.member.roles.cache.has("1053317581043404871") && message.author.id !== client.user.id) return;
      message.delete();
message.channel.send({content: "https://cdn.discordapp.com/attachments/1286330575954771998/1286383586592952413/1076927196993699870.jpg?ex=66f3a452&is=66f252d2&hm=7597db589549cd7f91121d9f31fe1d1156975ac3914814d3ed309e3acea36ecb&"})
      message.channel.send({
        content: `**
تـم اغـلاق الـشـات  <a:pp643:967627080995070014> 

{ ويـرجـى مـن جـمـيـع مـن لـديـهـم الـصـلاحـيـات عـدم الـكـتابـة بـدون سـبـب حـتى لايـتـم مـعـاقـبـتـهـم وشـكـراً لـكــم <a:pp643:967627080995070014> }


\` # \`  تم قفل الشات من قِبل الاداري:
${message.author}
**`
       });
 message.channel.send({content: "https://cdn.discordapp.com/attachments/1286330575954771998/1286383586592952413/1076927196993699870.jpg?ex=66f3a452&is=66f252d2&hm=7597db589549cd7f91121d9f31fe1d1156975ac3914814d3ed309e3acea36ecb&"})

      return;
    }

        if (message.content === "ف" || message.content === "ففل") {
      if (!message.member.roles.cache.has("1287323086055669790") && message.author.id !== client.user.id) return;
      message.delete();
message.channel.send({content: "https://cdn.discordapp.com/attachments/1286330575954771998/1286383586592952413/1076927196993699870.jpg?ex=66f3a452&is=66f252d2&hm=7597db589549cd7f91121d9f31fe1d1156975ac3914814d3ed309e3acea36ecb&"})
      message.channel.send({
        content: `**
تـم فتـح الـشـات ✅

{ ويـرجـى مـن جـمـيـع المـواطـنيـن الاحـتـرام والـتقـديـر المـتـبـادل وعـدم المـشاكل والـحـقـد والـعـنـصـريـة نـحن عـائـلـة مـش مـجـرد سـيـرفـر ✅ }

\` # \`  تم فتح الشات من قِبل الاداري:
${message.author}
**`
       });
 message.channel.send({content: "https://cdn.discordapp.com/attachments/1286330575954771998/1286383586592952413/1076927196993699870.jpg?ex=66f3a452&is=66f252d2&hm=7597db589549cd7f91121d9f31fe1d1156975ac3914814d3ed309e3acea36ecb&"})

      return;
    }

    if (message.content === " " || message.content === " ") {
      if (!message.member.roles.cache.has("1053317581043404871") && message.author.id !== client.user.id) return;
message.reply(`**

\` # \`
 اوامر <@&987310088681299999>
\` # \`


\` -تصويت \`
_اول ما تنزل قيم اكتب هذا مره وحده فقط في <#1080508937935274104>_


\` -ارسال \`
_اول ما يجي موعد التجوين نزل هذا الامر مره وحده فقط في <#1080508937935274104>_


\` -تجوين \`
_وبعديها بخمس دقايق تكون فتحت الماب وظبط كل شي نزل هذا الامر مره وحده فقط في <#1080508937935274104>_


\` -تم \`
_استخدم هذا الامر قبل ان تبدا القيم في <#1080444463387787364>_


\` -بدء \`
_هذا الامر استخدمه في <#1080444388834033694> وبعديها تبدا القيم_


\` القوانين \`
_لارسال قوانين القيم _


\` قفل ، ق  \`
_لقفل الروم وارسال رسالة القفل_

-

 \` ملاحظة \`:   الاوامر كلها تستخدم مره وحده فقط 

-

\` امر من: \`
${message.author}

**
~~ <@&987310088681299999>  ~~

`
       );
 message.channel.send({content: "https://media.discordapp.net/attachments/1064519307679244299/1100857369287733338/29_.png"})

      
      return;
    }  
    
    if (message.content === "القوانين") {
      if (!message.member.roles.cache.has("1053317581043404871") && message.author.id !== client.user.id) return;
      message.delete();
message.channel.send({content: "https://media.discordapp.net/attachments/1064519307679244299/1100857369287733338/29_.png"})
      message.channel.send({
        content: `**
# السلام عليكم ورحمة الله وبركاته #

__ منورين سيرفر لايف كينق حياكم الله __

\` 1- \` اول شي اتمنى الجميع يراجع القوانين

\` 2- \` اول 10 ثواني لاحد يتحرك

\` 3- \` اول 10 دقايق ممنوع تروح المركز

\` 4- \` تروح كراج توقف عند سياره توقف وما تتحرك اذا تحركت راح تأخذ تحذير اول

\` 5- \` ممنوع اي عصابه اول 10 دقايق يسوي حاله اجراميه

\` 6- \` ممنوع اي مواطن ياخذ سياره عسكري تحذير اول

\` 7- \` اي عسكري ياخذ سيارة مواطن تحذير اول و تنزيل رتبه

\` 8- \` ممنوع التدخل الخارجي 

__ رحلة جميلة انشاء الله __
~~ # @here # ~~
**`
      });
message.channel.send({content: "https://cdn.discordapp.com/attachments/1270258103538946090/1286671925283913749/0E07A7AA-A53E-4557-9113-39333BC5DBE3.jpg?ex=66f4081c&is=66f2b69c&hm=2ffbd5da93fdbf011d4824901a5dd5816133f7c191f28f0c1e7f6b448c895bc5&"})
      return;
    }

    if (message.author.bot) return;
  }
};
