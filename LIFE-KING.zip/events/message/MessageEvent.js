const BaseEvent = require('../../utils/structures/BaseEvent');

module.exports = class MessageEvent extends BaseEvent {
  constructor() {
    super('messageCreate');
  }
  
  async run(client, message) {
    if(message.content == "خط"){
      if(!message.member.roles.cache.has("1287323086055669790") && message.author.id != client.user.id) return
      message.delete()
      message.channel.send({content : "https://media.discordapp.net/attachments/1232375777480278127/1289893740495769632/file.jpg?ex=66fa7aa8&is=66f92928&hm=593e8e93254a788552edde169008f178d31c399ed885ec5675772c4916fb53f4&=&format=webp&width=1052&height=62"})
      return
  }
    if (message.author.bot) return;

    if (message.content.startsWith(client.prefix)) {
      const [cmdName, ...cmdArgs] = message.content
      .slice(client.prefix.length)
      .trim()
      .split(/\s+/);
      const command = client.commands.get(cmdName);
      if (command) {
        command.run(client, message, cmdArgs);
      }
    }
  }
}