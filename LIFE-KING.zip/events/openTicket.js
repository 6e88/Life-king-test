//@ts-nocheck
// https://discord.js.org/#/docs/main/stable/class/Client?scrollTo=e-interactionCreate
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('@discordjs/builders');
const { Client, PermissionFlagsBits, ButtonStyle } = require('discord.js');
const BaseEvent = require('../utils/structures/BaseEvent');
const s = require('../config');
const { catg } = require('../config');
const db = require("pro.db")
module.exports = class InteractionCreateEvent extends BaseEvent {
  constructor() {
    super('');
  }
  /**
   * 
   * @param {Client} client 
   * @param {import('discord.js').Interaction} interaction 
   */
  async run(client, interaction) {
    if (!interaction.isButton()) return
    let sri = s.supportId //ايدي رتبة السبورت
    if (interaction.customId == "open") {
        db.add("www1",1)
      let ch = await interaction.guild?.channels.create({
        name: `ticket-${db.get("www1")}`,
        permissionOverwrites: [
          {
            id: interaction.guildId,
            deny: PermissionFlagsBits.ViewChannel
          },
          {
            id: interaction.member.id,
            allow: [PermissionFlagsBits.ViewChannel,PermissionFlagsBits.MentionEveryone,PermissionFlagsBits.AttachFiles]
          },
          {
            id: sri,
            allow: PermissionFlagsBits.ViewChannel
          }
        ],
        parent: catg
      })
      ch.send({content : `
<@&${sri}> - ${interaction.member}
**__ 
<a:00:1267215437603537058> — مـرحـبـا بـك عـزيـزي الـعـضـو فـي قـسـم الـتـفـعـيـل .

<:LK:1289524430220820593> — لـلـتـفـعـيـل فـي لايـف كـيـنـق الـرجـاء اكـتـب ( L1 ) .

<a:FNothing19:1267215441110237216> — ويـرجـى الالـتـزام بالانـظـمـة الـمـوضـحـة ادنـاه .

1 — احـتـرام الاداري .
2 — عـدم اكـثـار مـنـشـن
3 — عـدم الـتـأخـر فـي الـرد

<a:93DF6B7880944A298485A6FC945B707D:1289891417413517385> — نـرجـو الالـتـزام بالانـظـمـة وعـدم مـخـالـفـتـهـا .

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق ) __** 
`,
    embeds : [new EmbedBuilder()
      .setTitle(`التفعيل`)
      .setTimestamp()
      .setColor(0xEAE843)
      .setDescription(`**__مرحبا بك عزيزي العضو في قسم التفعيل   .

  نرجو منك عزيزي العضو إنتضار إستلام التكت من قبل الادارة __**`)],
components : [new ActionRowBuilder()
  .addComponents(
    new ButtonBuilder()
      .setCustomId("claim")
      .setStyle(ButtonStyle.Success)
      .setLabel("استلام"),
    new ButtonBuilder()
      .setCustomId("trk")
      .setStyle(ButtonStyle.Secondary)
      .setLabel("ترك"),
    new ButtonBuilder()
      .setCustomId("delete")
      .setStyle(ButtonStyle.Danger)
      .setLabel("حذف")
  )]})
  interaction.reply({content: `${ch}`,ephemeral:true})
    }
  }
}